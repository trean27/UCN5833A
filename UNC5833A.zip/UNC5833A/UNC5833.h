#ifndef UNC5833_H
#define UNC5833_H

#include <Arduino.h>

class UNC5833 {
public:
  // Define all constants for outputs
  static constexpr uint32_t Out1 = (1UL << 0);
  static constexpr uint32_t Out2 = (1UL << 1);
  static constexpr uint32_t Out3 = (1UL << 2);
  static constexpr uint32_t Out4 = (1UL << 3);
  static constexpr uint32_t Out5 = (1UL << 4);
  static constexpr uint32_t Out6 = (1UL << 5);
  static constexpr uint32_t Out7 = (1UL << 6);
  static constexpr uint32_t Out8 = (1UL << 7);
  static constexpr uint32_t Out9 = (1UL << 8);
  static constexpr uint32_t Out10 = (1UL << 9);
  static constexpr uint32_t Out11 = (1UL << 10);
  static constexpr uint32_t Out12 = (1UL << 11);
  static constexpr uint32_t Out13 = (1UL << 12);  
  static constexpr uint32_t Out14 = (1UL << 13);
  static constexpr uint32_t Out15 = (1UL << 14);
  static constexpr uint32_t Out16 = (1UL << 15);
  static constexpr uint32_t Out17 = (1UL << 16);
  static constexpr uint32_t Out18 = (1UL << 17);
  static constexpr uint32_t Out19 = (1UL << 18);
  static constexpr uint32_t Out20 = (1UL << 19);
  static constexpr uint32_t Out21 = (1UL << 20);
  static constexpr uint32_t Out22 = (1UL << 21);
  static constexpr uint32_t Out23 = (1UL << 22);
  static constexpr uint32_t Out24 = (1UL << 23);
  static constexpr uint32_t Out25 = (1UL << 24);
  static constexpr uint32_t Out26 = (1UL << 25);
  static constexpr uint32_t Out27 = (1UL << 26);
  static constexpr uint32_t Out28 = (1UL << 27);
  static constexpr uint32_t Out29 = (1UL << 28);
  static constexpr uint32_t Out30 = (1UL << 29);
  static constexpr uint32_t Out31 = (1UL << 30);
  static constexpr uint32_t Out32 = (1UL << 31);


  // Constructor
  UNC5833(uint8_t strobePin, uint8_t outputEnablePin, uint8_t dataInPin, uint8_t clockPin);

  // Write methods
  void write(uint32_t data);
  void write(uint32_t data1, uint32_t data2);

private:
  uint8_t strobePin, outputEnablePin, dataInPin, clockPin;
  
  // Private helper to shift out 32-bit data
  void shiftOutData(uint32_t data);
};

#endif