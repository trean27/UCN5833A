#include "UNC5833.h"

// Constructor implementation
UNC5833::UNC5833(uint8_t strobePin, uint8_t outputEnablePin, uint8_t dataInPin, uint8_t clockPin)
  : strobePin(strobePin), outputEnablePin(outputEnablePin), dataInPin(dataInPin), clockPin(clockPin) {
    pinMode(strobePin, OUTPUT);
    pinMode(outputEnablePin, OUTPUT);
    pinMode(dataInPin, OUTPUT);
    pinMode(clockPin, OUTPUT);
    digitalWrite(strobePin, LOW);
    digitalWrite(outputEnablePin, LOW);
}

// Helper function to shift out 32-bit data
void UNC5833::shiftOutData(uint32_t data) {
  shiftOut(dataInPin, clockPin, MSBFIRST, (data >> 24) & 0xFF);
  shiftOut(dataInPin, clockPin, MSBFIRST, (data >> 16) & 0xFF);
  shiftOut(dataInPin, clockPin, MSBFIRST, (data >> 8) & 0xFF);
  shiftOut(dataInPin, clockPin, MSBFIRST, data & 0xFF);
}

// Write a single 32-bit data value
void UNC5833::write(uint32_t data) {
  noInterrupts();
  digitalWrite(outputEnablePin, LOW);
  shiftOutData(data);
  digitalWrite(strobePin, HIGH);
  delayMicroseconds(2);
  digitalWrite(strobePin, LOW);
  digitalWrite(outputEnablePin, HIGH);
  interrupts();
}

// Write two 32-bit data values consecutively
void UNC5833::write(uint32_t data1, uint32_t data2) {
  noInterrupts();
  digitalWrite(outputEnablePin, LOW);
  shiftOutData(data2);
  shiftOutData(data1);
  digitalWrite(strobePin, HIGH);
  delayMicroseconds(2);
  digitalWrite(strobePin, LOW);
  digitalWrite(outputEnablePin, HIGH);
  interrupts();
}